#ifndef AI_PLAYER_H
#define AI_PLAYER_H

#include <iostream>
#include <cmath>
#include <vector>
#include <glm/glm.hpp>

class Player;
using namespace std;
#include "player.h"

/** make it extend the player, i guess. OR create an abstract class for Player/AIPlayer. */
class AIPlayer : public Player {

};
#endif